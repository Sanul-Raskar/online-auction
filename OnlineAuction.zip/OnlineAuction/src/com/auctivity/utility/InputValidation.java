package com.auctivity.utility;

public class InputValidation {

}
