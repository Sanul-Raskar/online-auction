package com.auctivity.utility;

public class Logger {

}
